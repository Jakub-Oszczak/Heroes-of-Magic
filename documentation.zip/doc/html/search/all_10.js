var searchData=
[
  ['takedamage_0',['takeDamage',['../class_mage.html#afc02ee6667a46ab1ae5b2c022c849e6b',1,'Mage']]],
  ['tankball_1',['Tankball',['../class_tankball.html',1,'Tankball'],['../class_tankball.html#ad76c25d7d5310b66c7050ece73c9888e',1,'Tankball::Tankball()']]],
  ['tankball_2ecpp_2',['Tankball.cpp',['../_tankball_8cpp.html',1,'']]],
  ['tankball_2eh_3',['Tankball.h',['../_tankball_8h.html',1,'']]],
  ['todelete_4',['toDelete',['../class_bullet.html#a25cfbe9e1c6d5e46289ab14427207d59',1,'Bullet']]]
];
