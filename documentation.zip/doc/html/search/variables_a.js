var searchData=
[
  ['scene_0',['scene',['../class_game.html#a8119e3b9a632906c6808fa294b46a92a',1,'Game']]],
  ['shotdirection_1',['shotDirection',['../class_bullet.html#a75393beba46ab451c33be204a43ce4ff',1,'Bullet']]]
];
