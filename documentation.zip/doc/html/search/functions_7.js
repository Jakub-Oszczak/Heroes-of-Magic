var searchData=
[
  ['mage_0',['Mage',['../class_mage.html#a9d7d4455a6fa1f8e35117e0dc301d082',1,'Mage']]],
  ['magicball_1',['Magicball',['../class_magicball.html#ab18ae7380bc79abbff9568a816b9c623',1,'Magicball']]],
  ['makecanshoottrue_2',['makeCanShootTrue',['../class_mage.html#a18b3982462501d99829b5c4009f04e2b',1,'Mage']]],
  ['move_3',['move',['../class_bullet.html#a6140db968c42c05e829e142f74f20b16',1,'Bullet::move()'],['../class_enemy.html#a9a398f8d12234f02563b27440aff7891',1,'Enemy::move()'],['../class_mage.html#a7c346f2ba62bd0002d00e3a70224369b',1,'Mage::move()'],['../class_player.html#acf41813d3be8e4c10676495c4e5a1ba8',1,'Player::move()']]]
];
