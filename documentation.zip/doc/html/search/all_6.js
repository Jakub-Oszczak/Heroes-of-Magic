var searchData=
[
  ['health_0',['Health',['../class_health.html',1,'']]],
  ['heroes_5fof_5fmagic_1',['Heroes_of_magic',['../index.html',1,'']]]
];
