var searchData=
[
  ['resetspeed_0',['resetSpeed',['../class_player.html#a1b49ef5ea620c07005b4f3619a569a63',1,'Player']]],
  ['returnbullet_1',['returnBullet',['../class_mage.html#a04e1e5e45f4018fb277fc2b34304c610',1,'Mage']]],
  ['returndirection_2',['returnDirection',['../class_mage.html#aedbba0b812f8f2d5a42f40502adc4df8',1,'Mage']]],
  ['returnenemy_3',['returnEnemy',['../class_game.html#a5d4fe1da892227d5e8dd39123c4b9a1e',1,'Game']]],
  ['returnenemymage_4',['returnEnemyMage',['../class_enemy.html#aa29ba2356afdb388b8e64d54dfaa37b7',1,'Enemy']]],
  ['returnhealth_5',['returnHealth',['../class_mage.html#a8baa376a7d46635493dd33fd99c2dd16',1,'Mage']]],
  ['returnmage_6',['returnMage',['../class_player.html#abac3314fcf32cdbf89b62f0ccf48dd64',1,'Player']]],
  ['returnmap_7',['returnMap',['../class_game.html#a62c3df7acaa2cb9b883b9aad30f19279',1,'Game']]],
  ['returnplayer_8',['returnPlayer',['../class_game.html#a58dbb5d0b4ed2fb8fb1556d47ea298f6',1,'Game']]],
  ['returnscene_9',['returnScene',['../class_game.html#aa8bd25291f3e5339f8c0dd78e21f5568',1,'Game']]]
];
