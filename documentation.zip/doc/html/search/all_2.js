var searchData=
[
  ['defineshotdirection_0',['defineShotDirection',['../class_bullet.html#af0d1874441e2cf1173c21f7e8d1ae23a',1,'Bullet']]],
  ['deleteatborder_1',['deleteAtBorder',['../class_bullet.html#ac6995d5079a5f4fbd88eb608614bf053',1,'Bullet']]]
];
