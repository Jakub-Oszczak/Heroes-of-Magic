var searchData=
[
  ['mage_0',['mage',['../class_g_mage.html#ac0471eb017c799de4f96fbb67f260428',1,'GMage']]],
  ['magetype_1',['mageType',['../class_mage.html#ac18c197179da8415dfa200278b54fc19',1,'Mage']]],
  ['map_2',['Map',['../class_map.html#a6014fb268c61ad1aafcac00eb3698eb8',1,'Map']]],
  ['map_3',['map',['../class_game.html#acef3a39fdf14be2c980b0dc11e7be402',1,'Game::map()'],['../class_g_map.html#a41266335ac6ae19d2338db6213349826',1,'GMap::map()']]],
  ['movespeed_4',['moveSpeed',['../class_mage.html#ab9e0ec8ecc767802fcf8d8de5f525e02',1,'Mage']]]
];
