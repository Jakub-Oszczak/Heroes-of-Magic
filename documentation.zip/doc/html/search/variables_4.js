var searchData=
[
  ['flipped_0',['flipped',['../class_mage.html#add157a7cb370b321b0519215db92c1b9',1,'Mage']]]
];
