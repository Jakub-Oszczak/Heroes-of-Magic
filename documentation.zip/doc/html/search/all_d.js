var searchData=
[
  ['takedamage_0',['takeDamage',['../class_mage.html#afc02ee6667a46ab1ae5b2c022c849e6b',1,'Mage']]],
  ['tankball_1',['Tankball',['../class_tankball.html',1,'Tankball'],['../class_tankball.html#ad76c25d7d5310b66c7050ece73c9888e',1,'Tankball::Tankball()']]]
];
