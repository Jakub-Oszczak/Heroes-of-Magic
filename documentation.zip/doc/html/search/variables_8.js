var searchData=
[
  ['obsposx_0',['obsPosX',['../class_non_movable.html#aae4bf8a33736eb243f62c793ef5cb989',1,'NonMovable']]],
  ['obsposy_1',['obsPosY',['../class_non_movable.html#aa9624d40a9e5b4886bb9d999488bc8e6',1,'NonMovable']]]
];
