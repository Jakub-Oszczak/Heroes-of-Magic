var searchData=
[
  ['player_0',['player',['../class_game.html#abec70aa1c0269a9a7e171af4d79e08bf',1,'Game::player()'],['../class_g_player.html#a5a8db90efd5f717329a26711cdd5e83d',1,'GPlayer::player()']]],
  ['playerhealth_1',['playerhealth',['../class_game.html#a3917a73a9e522dd88d2b89862f4e83e1',1,'Game']]],
  ['posx_2',['posx',['../class_mage.html#a2177719c308e14661122aa95fab96025',1,'Mage']]],
  ['posy_3',['posy',['../class_mage.html#a4cff6f83353c278d08b6b31ab6dca1f2',1,'Mage']]],
  ['prevposx_4',['prevPosX',['../class_mage.html#a8a27e5d6a4bf705dae59965c4a1c7898',1,'Mage']]],
  ['prevposy_5',['prevPosY',['../class_mage.html#a7e9bf8f527ba31aa5f2243b8daf99db5',1,'Mage']]]
];
