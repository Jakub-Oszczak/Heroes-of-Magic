var searchData=
[
  ['background_0',['background',['../class_map.html#ab97933abbc41d6ba79c87bdd5ba62663',1,'Map']]],
  ['bullet_1',['bullet',['../class_g_bullet.html#a5effcef1b1ecd3df2e76d075eb87da71',1,'GBullet']]],
  ['bulletposx_2',['bulletPosX',['../class_bullet.html#a48cb669e5c3d030c15d884e4a067ba45',1,'Bullet']]],
  ['bulletposy_3',['bulletPosY',['../class_bullet.html#a126213a5d4797c352d0f088549bf3230',1,'Bullet']]]
];
