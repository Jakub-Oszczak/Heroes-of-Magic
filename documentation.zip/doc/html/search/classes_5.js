var searchData=
[
  ['mage_0',['Mage',['../class_mage.html',1,'']]],
  ['magicball_1',['Magicball',['../class_magicball.html',1,'']]],
  ['map_2',['Map',['../class_map.html',1,'']]]
];
