var searchData=
[
  ['enemy_0',['enemy',['../class_game.html#aaaef99ac0f9bb6fc836e8195b0ea8756',1,'Game']]],
  ['enemyhealth_1',['enemyhealth',['../class_game.html#a38ad8e3036938b71c3df4c3c2defded9',1,'Game']]]
];
