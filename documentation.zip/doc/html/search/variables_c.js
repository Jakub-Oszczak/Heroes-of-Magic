var searchData=
[
  ['walkingdirection_0',['walkingDirection',['../class_mage.html#ac9672f6ea4b8f93b6d770587e23356f3',1,'Mage']]]
];
