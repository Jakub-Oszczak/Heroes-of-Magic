var searchData=
[
  ['game_0',['Game',['../class_game.html#ac1a9dde49041f68e14234a41a862865d',1,'Game']]],
  ['gameover_1',['gameOver',['../class_game.html#a09c06a026a0667957da5e03528e647aa',1,'Game']]]
];
