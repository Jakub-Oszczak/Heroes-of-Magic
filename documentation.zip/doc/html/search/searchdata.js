var indexSectionsWithContent =
{
  0: "bcdefghkmnprstw",
  1: "befghmnptw",
  2: "bcdefgkmprstw",
  3: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Funkcje",
  3: "Strony"
};

